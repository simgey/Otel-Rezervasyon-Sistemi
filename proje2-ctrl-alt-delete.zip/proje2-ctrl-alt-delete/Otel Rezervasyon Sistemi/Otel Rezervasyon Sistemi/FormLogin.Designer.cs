﻿namespace Otel_Rezervasyon_Sistemi
{
    partial class FormLogin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.Button btnTemizle;
            this.label1 = new System.Windows.Forms.Label();
            this.lblKullaniciAd = new System.Windows.Forms.Label();
            this.lblSifre = new System.Windows.Forms.Label();
            this.linklbluyeol = new System.Windows.Forms.LinkLabel();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.maskedTextBox1 = new System.Windows.Forms.MaskedTextBox();
            this.btnGiris = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.kullaniciGirisiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kullaniciGirisToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.yöneticiGirisToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tanıtımToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.iletişimToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.şikayetToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            btnTemizle = new System.Windows.Forms.Button();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(162, 337);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 18);
            this.label1.TabIndex = 0;
            // 
            // lblKullaniciAd
            // 
            this.lblKullaniciAd.AutoSize = true;
            this.lblKullaniciAd.Location = new System.Drawing.Point(51, 160);
            this.lblKullaniciAd.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblKullaniciAd.Name = "lblKullaniciAd";
            this.lblKullaniciAd.Size = new System.Drawing.Size(86, 18);
            this.lblKullaniciAd.TabIndex = 1;
            this.lblKullaniciAd.Text = "KullaniciAdi:";
            this.lblKullaniciAd.Click += new System.EventHandler(this.lblkullaniciad_Click);
            // 
            // lblSifre
            // 
            this.lblSifre.AutoSize = true;
            this.lblSifre.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblSifre.Location = new System.Drawing.Point(95, 207);
            this.lblSifre.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSifre.Name = "lblSifre";
            this.lblSifre.Size = new System.Drawing.Size(42, 18);
            this.lblSifre.TabIndex = 2;
            this.lblSifre.Text = "Sifre:";
            this.lblSifre.Click += new System.EventHandler(this.lblsifre_Click);
            // 
            // linklbluyeol
            // 
            this.linklbluyeol.AutoSize = true;
            this.linklbluyeol.Location = new System.Drawing.Point(182, 239);
            this.linklbluyeol.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.linklbluyeol.Name = "linklbluyeol";
            this.linklbluyeol.Size = new System.Drawing.Size(58, 18);
            this.linklbluyeol.TabIndex = 3;
            this.linklbluyeol.TabStop = true;
            this.linklbluyeol.Text = "Uye OL";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(165, 153);
            this.textBox1.Margin = new System.Windows.Forms.Padding(4);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(199, 24);
            this.textBox1.TabIndex = 4;
            // 
            // maskedTextBox1
            // 
            this.maskedTextBox1.Location = new System.Drawing.Point(165, 201);
            this.maskedTextBox1.Margin = new System.Windows.Forms.Padding(4);
            this.maskedTextBox1.Name = "maskedTextBox1";
            this.maskedTextBox1.Size = new System.Drawing.Size(199, 24);
            this.maskedTextBox1.TabIndex = 5;
            // 
            // btnGiris
            // 
            this.btnGiris.Location = new System.Drawing.Point(266, 284);
            this.btnGiris.Name = "btnGiris";
            this.btnGiris.Size = new System.Drawing.Size(98, 32);
            this.btnGiris.TabIndex = 6;
            this.btnGiris.Text = "Giris";
            this.btnGiris.UseVisualStyleBackColor = true;
            // 
            // btnTemizle
            // 
            btnTemizle.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            btnTemizle.Cursor = System.Windows.Forms.Cursors.No;
            btnTemizle.Location = new System.Drawing.Point(130, 284);
            btnTemizle.Name = "btnTemizle";
            btnTemizle.Size = new System.Drawing.Size(88, 32);
            btnTemizle.TabIndex = 7;
            btnTemizle.Text = "Temzile";
            btnTemizle.UseVisualStyleBackColor = true;
            btnTemizle.Click += new System.EventHandler(this.btnTemizle_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.Location = new System.Drawing.Point(124, 77);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(282, 31);
            this.label2.TabIndex = 8;
            this.label2.Text = "Kullanici Giris Paneli";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.kullaniciGirisiToolStripMenuItem,
            this.tanıtımToolStripMenuItem,
            this.iletişimToolStripMenuItem,
            this.şikayetToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(517, 24);
            this.menuStrip1.TabIndex = 9;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // kullaniciGirisiToolStripMenuItem
            // 
            this.kullaniciGirisiToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.kullaniciGirisToolStripMenuItem,
            this.yöneticiGirisToolStripMenuItem});
            this.kullaniciGirisiToolStripMenuItem.Name = "kullaniciGirisiToolStripMenuItem";
            this.kullaniciGirisiToolStripMenuItem.Size = new System.Drawing.Size(64, 20);
            this.kullaniciGirisiToolStripMenuItem.Text = "Giris Yap";
            // 
            // kullaniciGirisToolStripMenuItem
            // 
            this.kullaniciGirisToolStripMenuItem.Name = "kullaniciGirisToolStripMenuItem";
            this.kullaniciGirisToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.kullaniciGirisToolStripMenuItem.Text = "Kullanici Giris";
            // 
            // yöneticiGirisToolStripMenuItem
            // 
            this.yöneticiGirisToolStripMenuItem.Name = "yöneticiGirisToolStripMenuItem";
            this.yöneticiGirisToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.yöneticiGirisToolStripMenuItem.Text = "Yönetici Giris";
            // 
            // tanıtımToolStripMenuItem
            // 
            this.tanıtımToolStripMenuItem.Name = "tanıtımToolStripMenuItem";
            this.tanıtımToolStripMenuItem.Size = new System.Drawing.Size(58, 20);
            this.tanıtımToolStripMenuItem.Text = "Tanıtım";
            // 
            // iletişimToolStripMenuItem
            // 
            this.iletişimToolStripMenuItem.Name = "iletişimToolStripMenuItem";
            this.iletişimToolStripMenuItem.Size = new System.Drawing.Size(57, 20);
            this.iletişimToolStripMenuItem.Text = "İletişim";
            // 
            // şikayetToolStripMenuItem
            // 
            this.şikayetToolStripMenuItem.Name = "şikayetToolStripMenuItem";
            this.şikayetToolStripMenuItem.Size = new System.Drawing.Size(59, 20);
            this.şikayetToolStripMenuItem.Text = "Şikayet ";
            // 
            // FormLogin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightGray;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(517, 403);
            this.Controls.Add(this.label2);
            this.Controls.Add(btnTemizle);
            this.Controls.Add(this.btnGiris);
            this.Controls.Add(this.maskedTextBox1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.linklbluyeol);
            this.Controls.Add(this.lblSifre);
            this.Controls.Add(this.lblKullaniciAd);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.menuStrip1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "FormLogin";
            this.Text = "Login";
            this.Load += new System.EventHandler(this.FormLogin_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblKullaniciAd;
        private System.Windows.Forms.Label lblSifre;
        private System.Windows.Forms.LinkLabel linklbluyeol;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.MaskedTextBox maskedTextBox1;
        private System.Windows.Forms.Button btnGiris;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem kullaniciGirisiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kullaniciGirisToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem yöneticiGirisToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tanıtımToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem iletişimToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem şikayetToolStripMenuItem;
    }
}

